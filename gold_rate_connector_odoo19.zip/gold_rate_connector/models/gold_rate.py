import logging
from datetime import datetime, timezone

import requests

from odoo import api, fields, models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

OZ_TO_G = 31.1034768  # troy ounce to gram


class GoldRate(models.Model):
    _name = "gold.rate"
    _description = "Gold Rate"
    _order = "rate_datetime desc"

    rate_datetime = fields.Datetime(string="Rate Time", required=True, index=True)
    company_id = fields.Many2one("res.company", required=True, default=lambda self: self.env.company, index=True)
    currency_id = fields.Many2one("res.currency", required=True, index=True)
    price_per_ounce = fields.Float(string="Price per Troy Ounce", digits=(16, 6), required=True)
    price_per_gram = fields.Float(string="Price per Gram", digits=(16, 6), required=True)
    provider = fields.Selection(
        selection=[
            ("metals_api", "Metals-API"),
            ("goldapi_io", "GoldAPI.io"),
            ("gold_api_com", "Gold-API.com"),
        ],
        required=True,
    )
    raw_payload = fields.Text(string="Raw Payload")

    @api.model
    def _get_config(self):
        ICP = self.env["ir.config_parameter"].sudo()
        provider = ICP.get_param("gold_rate_connector.api_provider", default="metals_api")
        api_key = ICP.get_param("gold_rate_connector.api_key")
        base_currency_id = ICP.get_param("gold_rate_connector.base_currency_id")
        base_currency = self.env["res.currency"].browse(int(base_currency_id)) if base_currency_id else self.env.company.currency_id
        return provider, api_key, base_currency

    @api.model
    def _fetch_from_metals_api(self, api_key, base_currency):
        if not api_key:
            raise UserError(_("Metals-API requires an API key. Set it in Settings."))
        # Metals-API returns rates as: 1 BASE = rate * SYMBOL
        # If we request SYMBOL=XAU, we get XAU per 1 BASE.
        # We want price of 1 XAU in BASE => 1 / rate.
        url = "https://metals-api.com/api/latest"
        params = {
            "access_key": api_key,
            "base": base_currency.name,  # e.g. EGP, USD
            "symbols": "XAU",
        }
        r = requests.get(url, params=params, timeout=20)
        r.raise_for_status()
        payload = r.json()
        if not payload.get("success", True):
            raise UserError(_("Metals-API error: %s") % payload)
        rate_xau = (payload.get("rates") or {}).get("XAU")
        if not rate_xau:
            raise UserError(_("Metals-API response missing XAU rate."))
        price_per_ounce = 1.0 / float(rate_xau)  # BASE per 1 XAU (troy ounce)
        return price_per_ounce, payload

    @api.model
    def _fetch_from_goldapi_io(self, api_key, base_currency):
        if not api_key:
            raise UserError(_("GoldAPI.io requires an API key. Set it in Settings."))
        # GoldAPI.io commonly uses X-Access-Token header. Endpoint returns price per ounce in requested currency.
        # Docs may evolve; if it differs in your plan, adjust endpoint/headers accordingly.
        url = f"https://www.goldapi.io/api/XAU/{base_currency.name}"
        headers = {"x-access-token": api_key}
        r = requests.get(url, headers=headers, timeout=20)
        r.raise_for_status()
        payload = r.json()
        # common field names: 'price' or 'price_oz'
        price_per_ounce = payload.get("price") or payload.get("price_oz")
        if not price_per_ounce:
            raise UserError(_("GoldAPI.io response missing price field."))
        return float(price_per_ounce), payload

    @api.model
    def _fetch_from_gold_api_com(self, _api_key_unused, base_currency):
        # gold-api.com is usually keyless. Endpoint patterns may differ; adjust if needed.
        # Common pattern: /price/XAU or /price/XAU?currency=EGP
        url = "https://gold-api.com/price/XAU"
        params = {"currency": base_currency.name}
        r = requests.get(url, params=params, timeout=20)
        r.raise_for_status()
        payload = r.json()
        # common field name: 'price'
        price_per_ounce = payload.get("price")
        if not price_per_ounce:
            raise UserError(_("Gold-API.com response missing price field."))
        return float(price_per_ounce), payload

    @api.model
    def fetch_and_store_gold_rate(self):
        provider, api_key, base_currency = self._get_config()
        company = self.env.company

        if provider == "metals_api":
            price_oz, payload = self._fetch_from_metals_api(api_key, base_currency)
        elif provider == "goldapi_io":
            price_oz, payload = self._fetch_from_goldapi_io(api_key, base_currency)
        elif provider == "gold_api_com":
            price_oz, payload = self._fetch_from_gold_api_com(api_key, base_currency)
        else:
            raise UserError(_("Unknown provider: %s") % provider)

        price_g = price_oz / OZ_TO_G

        now_utc = datetime.now(timezone.utc).replace(tzinfo=None)  # store naive UTC like Odoo does
        rec = self.create({
            "rate_datetime": now_utc,
            "company_id": company.id,
            "currency_id": base_currency.id,
            "price_per_ounce": price_oz,
            "price_per_gram": price_g,
            "provider": provider,
            "raw_payload": str(payload),
        })
        _logger.info("Gold rate updated: %s %s/oz (%s/g) via %s", base_currency.name, price_oz, price_g, provider)
        return rec

    @api.model
    def _cron_fetch_gold_rate(self):
        # Cron entry point
        try:
            self.with_company(self.env.company).fetch_and_store_gold_rate()
        except Exception as e:
            _logger.exception("Gold Rate cron failed: %s", e)
            # Do not raise to avoid disabling cron on transient issues
            return False
        return True

    @api.model
    def get_latest_rate(self, company_id=None, currency_id=None):
        domain = []
        if company_id:
            domain.append(("company_id", "=", company_id))
        if currency_id:
            domain.append(("currency_id", "=", currency_id))
        return self.search(domain, order="rate_datetime desc", limit=1)
