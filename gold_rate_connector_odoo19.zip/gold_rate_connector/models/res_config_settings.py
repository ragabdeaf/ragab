from odoo import api, fields, models

class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    gold_api_provider = fields.Selection(
        selection=[
            ("metals_api", "Metals-API (metals-api.com)"),
            ("goldapi_io", "GoldAPI.io (goldapi.io)"),
            ("gold_api_com", "Gold-API.com (gold-api.com)"),
        ],
        string="Gold API Provider",
        default="metals_api",
        config_parameter="gold_rate_connector.api_provider",
    )
    gold_api_key = fields.Char(
        string="Gold API Key",
        config_parameter="gold_rate_connector.api_key",
        help="API key/token for the selected provider (if required).",
    )
    gold_base_currency_id = fields.Many2one(
        "res.currency",
        string="Base Currency for Gold Price",
        config_parameter="gold_rate_connector.base_currency_id",
        help="Currency you want the gold price expressed in (e.g., EGP).",
    )
    gold_update_interval_minutes = fields.Integer(
        string="Update Interval (minutes)",
        default=60,
        config_parameter="gold_rate_connector.update_interval_minutes",
        help="Cron interval; change it and update the Scheduled Action if needed.",
    )

    @api.model
    def set_values(self):
        res = super().set_values()
        # If user didn't set a base currency, default to current company currency
        company = self.env.company
        if not self.gold_base_currency_id:
            self.env["ir.config_parameter"].sudo().set_param(
                "gold_rate_connector.base_currency_id", company.currency_id.id
            )
        return res
