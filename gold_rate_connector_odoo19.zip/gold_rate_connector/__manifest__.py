{
    "name": "Gold Rate Connector",
    "version": "19.0.1.0.0",
    "summary": "Fetch and store gold prices (XAU) via API, with scheduled updates.",
    "category": "Accounting/Accounting",
    "author": "Your Company",
    "license": "LGPL-3",
    "depends": ["base", "account"],
    "data": [
        "security/ir.model.access.csv",
        "views/gold_rate_views.xml",
        "views/res_config_settings_views.xml",
        "data/ir_cron.xml",
    ],
    "installable": True,
    "application": False,
}
